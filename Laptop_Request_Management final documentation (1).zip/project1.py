#shopkeeper data:
sk_name='pujitha'
sk_password='2345'
#shop data
veg=['tamoto','potapo','cabbage','carrot','mushroom','pumpkin','broccoli','brinjal','capsicum','beetroot']
quantity=[30,40,50,20,50,60,70,80,40,20]
price=[30,40,20,10,50,30,20,40,50,30]
phn=[]
cart=[]
qty=[]
prc=[]


while True:
    print('------------------------------------------')
    print('1.shopkeeper')
    print('2.customer')
    print('3.exit')
    ch=int(input('choose one option: '))
    if ch==1:
        attempts=3
        while attempts>0:
            name=input('enter your name: ')
            password=input('enter your password: ')
            if name==sk_name and password==sk_password:
                print('login successfully')
                while True:
                    print('1.add')
                    print('2.remove')
                    print('3.modify')
                    print('4.view inventory')
                    print('5.view report')
                    print('6.total revenue and itemized profit')
                    print('7.exit')
                    d=int(input('choose one option: '))
                    if d==1:
                       item=input('enter name of element: ')
                       d=int(input('enter quantity of item: '))
                       s=int(input('enter a price of elements: '))
                       if item in veg:
                          print('already available that item')
                       else:    
                           veg.append(item)
                           quantity.append(d)
                           price.append(s)
                           print('added successfully')
                    elif d==2:
                       item=input('enter name of the element: ')
                       if item in veg:
                          index=veg.index(item)
                          veg.pop(index)
                          quantity.pop(index)
                          price.pop(index)
                          print('remove successfully')
                       else:
                           print('item not found')
                    elif d==3:
                        item=input('enter name of the element: ')
                        if item in veg:
                           index=veg.index(item)
                           print('1.quantity')
                           print('2.price')
                           i=int(input('choose one option: '))
                           if i==1:
                              n=float(input('enter quantity of item: '))
                              quantity[index]=n
                              print('quantity updated successfully')
                           elif i==2:
                               new_price=int(input('enter price of item: '))
                               price[index]=new_price
                               print('price updated successfully')
                           else:
                               print('choose currect option: ')
                    elif d==4:
                        print('\n vegetables,--quantity,- price,- total')
                        print('\n-------------------------------')
                        for i in range(len(veg)):
                           total=quantity[i]*price[i]
                           print(veg[i], '-\t', quantity[i], '\t', price[i],'\t', total)
                    elif d==5:
                        print('--------------view report----------------------')
                        print('vegetables:',len(veg))
                        print('quantity:',len(quantity))
                        print('price:', len(price))
                        for i in range(len(veg)):
                            print(veg[i],'-\t',quantity[i],'kgs\t',price[i],'rupees')
                    elif d==6:
                        print('1.total_revenue')
                        print('2.itemized_profit')
                        ch=int(input('choose one option: '))
                        if ch == 1:
                            total_revenue = 0
                            for i in range(len(veg)):
                                total_revenue += quantity[i] * price[i]
                            print('Total Revenue =', total_revenue, 'rupees')
                        elif ch == 2:
                            print('\nItemized Profit Report')
                            print('---------------------------------')
                            for i in range(len(veg)):
                                total = quantity[i] * price[i]
                                print(veg[i], '→', total, 'rupees')

                        else:
                            print('choose currect option')
                    elif d==7:
                        p=input('do you want to exit?(yes/no):')
                        if p=='yes':
                           print('thank you')
                           break
                    else:
                        print('choose correct option')
            else:
                attempts-=1
                print('your enter wrong password please try again')
        if attempts==0:
               print('login failed 3 times!returning to main menu')
               

    elif ch==2:
        while True:
            print('1.add cart')
            print('2.remove cart')
            print('3.modify cart')
            print('4.view cart')
            print('5.billing')
            print('6.exit')
            s=int(input('choose one correct option'))
            if s==1:
                while True:
                    item=input('what do you want:')
                    if item in veg:
                        index=veg.index(item)
                        qty_value=float(input('how many kgs you want: '))
                        if qty_value<=quantity[index]:
                            cart.append(item)
                            qty.append(qty_value)
                            prc.append(price[index])
                            quantity[index]=quantity[index]-qty_value
                            print('item added to cart successfully')
                        else:
                            print('quantity are not available')
                    else:
                        print('item is not available')
                    ch=input('do you want to add another item?(yes/no): ')
                    if ch=='no':
                        break
            elif s==2:
                if len(cart)==0:
                     print('cart is empty,nothing to modify.')
                else:
                    print('your cart items:',cart)
                    remove_item=input('what item do you want to remove? ')
                    if remove_item in cart:
                        index=cart.index(remove_item)
                        cart.pop(index)
                        qty.pop(index)
                        prc.pop(index)
                        print(remove_item,'remove from cart successfully')
            elif s==3:
                 if len(cart)==0:
                     print('cart is empty,nothing to modify.')
                 else:    
                     print('your cart items:',cart)
                     item=input('enter name of the element: ')
                     if item in cart:
                        index=cart.index(item)
                        print('1.qty')
                        print('2.prc')
                        i=int(input('choose one option: '))
                        if i==1:
                            n=float(input('enter quantity of item: '))
                            qty[index]=n
                            print('qty updated successfully')
                        elif i==2:
                            new_price=int(input('enter price of item: '))
                            prc[index]=new_price
                            print('price updated successfully')
                        else:
                            print('choose correct option: ')
            
            elif s==4:
                if len(cart) == 0:
                    print('Cart is empty, nothing to view.')
                else:
                    print('--------------view cart----------------------')
                    print('vegetables:',len(cart))
                    print('quantity:',len(qty))
                    print('price:', len(prc))
                    for i in range(len(cart)):
                        print(cart[i],'-\t',qty[i],'kgs\t',prc[i],'rupees')
            elif s==5:
                if len(cart)==0:
                    print('cart is empty,nothing to bill')
                else:
                    print('-----------------billing-----------------')

                    while True:
                         print('---------customer details-------------')
                         phone_num=int(input('enter a phn num: '))
                         bkp=phone_num
                         count=0
                         while phone_num>0:
                             phone_num=phone_num//10
                             count=count+1
                         phone_num=bkp    
                         if count==10:
                            if phone_num not in phn:
                               phn.append(phone_num)
                               break
                            else:
                                print('this number is already registered')
                         else:
                             print('enter correct phn number')
             
                    total=0
                    for i in range(len(cart)):
                        item_total=qty[i]*prc[i]
                        total=total+item_total
                        print(cart[i],'-',qty[i],'*',prc[i],'=',item_total)
                    print('total amount=',total,'rupees')
                    print('thank you for shopping')
            elif s==6:
                p=input('do you want to exit?(yes/no):')
                if p=='yes':
                    print('thank you')
                    break
            else:
                print('choose correct option')
    elif ch==3:
        p=input('do you want to exit?(yes/no):')
        if p=='yes':
            print('thank you')
            break
    else:
        print('choose correct option')