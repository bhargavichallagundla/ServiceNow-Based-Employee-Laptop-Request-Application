'''class Test:
  def __init__(self):
     self.a=10
     self.b=20
  def m1(self):
    del(self.a)
    self.c=30
t=Test()
t.d=40
t.e=50
t.f=60
t.e=100
t.m1()
print(t.__dict__)'''



'''t=(1,(2,3),(4,5))
x=(i for i in reversed(t))
print(type(x))
result=tuple(tuple(reversed(i)) if isinstance(i,tuple) else i for i in reversed(t))
print(result)'''


'''num = int(input("Enter a number: "))

if num <= 1:
    print("Not a Prime Number")
else:
    for i in range(2,num):
        if num % i == 0:
            print("Not a Prime Number")
    else:
        print("Prime Number")'''


'''start = 10
end = 30

print(f"Prime numbers between {start} and {end} are:")

for num in range(start, end + 1):
    if num > 1:
        for i in range(2,num):
            if num % i == 0:
                break
        else:
            print(num)'''


'''num=int(input("enter a number: "))
if num>0:
   print("positive")
elif num<0:
   print("negative")
else:
   print("equal to zero")'''


'''a=int(input("enter the marks: "))
if a>=90:
   print("grade a")
elif a>=75:
   print("grade b")
elif a>=50:
   print("grade c")
else:
   print("fail")'''



'''a=int(input("entre the year: "))
if a%4==0:
  print("leep year")
else:
  print("not a leep year")'''



'''a=input("enter a username : ")
b=input("enter a password: ")
if a=="admin":
  print("login succesfully")
elif b=="1234":
  print("login succesfully")
else:
  print("invalid credentials")''' 

  

'''a=int(input("entre a number: "))
b=int(input("entre a number: "))
c=int(input("entre a number: "))
if a>b:
  if a>c:
    print("ais greater")
  else:
    print("b is greater")
elif b>c:
   print("b is greater")
else:
   print("c is greater")'''



'''n=int(input("enter a number: "))
i=0
while i<=n:
  i=i+1
  print(i)'''

'''n=int(input("enter a number: "))
total=0
i=1
while i<=n:
  total+=i
  i+=1
print(total)'''


'''num=int(input("entre a number"))
original=num
reverse=0
while num>0:
  digit=num%10
  reverse=reverse*10+digit
  num = num // 10
if (original)==reverse:
  print("it is a palindrome")
else:
  print("not a palindrome")'''
   

'''num = int(input("Enter a number: "))
original = num
sum_of_powers = 0
temp = abs(num)
digits = 0
while temp > 0:
    temp = temp // 10
    digits += 1
temp = abs(num)
while temp > 0:
    digit = temp % 10
    sum_of_powers += digit ** digits
    temp = temp // 10

if sum_of_powers == abs(original):
    print("The number is an Armstrong number.")
else:
    print("The number is not an Armstrong number.")'''


'''n=int(input("enter a number: "))
i=0
for i in range(1,n+1):
  print(i)'''

'''num=int(input("enter a number: "))
for i in range(1,11):
  print(num,'x',i,"=",num*i)'''

'''num=int(input("enter a number: "))
factorial=1
for i in range(1,num+1):
  factorial *= i
print("Factorial of", num, "is", factorial)'''



'''num = int(input("Enter a number: "))
if num > 1:
    for i in range(2, num):
        if num % i == 0:
            print(num, "is not a Prime Number")
            break
    else:
        print(num, "is a Prime Number")
else:
    print(num, "is not a Prime Number")'''



'''class Employee:
    def__init__(self,name,sal,has_car)
       self.name=name
       self.sal=sal
       self.has_car=has_car
    def display(self):
       print(self.name)
e1=Employee('kiran',20000,false)
e2=Employee('ramu',30000,false)
e3=Employee('chandu',50000,true)
e4=Employee('uma',10000,true)
e5=Employee('geetha',15000,false)
l=[e1,e2,e3,e4,e5]
output=filter(lambda e:e.sal>10000 and e.sal<50000 and e.has_car==false,l)
for e in output:
  e.display()'''

'''l=[]
l.append(10)
print(l)
l.append(20)
print(l)
l.append(30)
print(l)
l.append(40)
print(l)'''



'''l=[1,4,5,9,10]
l.insert(3,11)
print(l)'''


'''l=[1,2,9,3,5]
l.remove(9)
print(l)
l.pop()
print(l)'''


'''a=[1,2,1,4,2,5,6,4]
count=a.count(2)
print(count)'''



'''numbers = []

n = int(input("Enter the number of elements: "))

for i in range(n):
    element = int(input("Enter element: "))
    numbers.append(element)

print("Original List:", numbers)
numbers.sort()
print("List in Ascending Order:", numbers)
numbers.sort(reverse=True)
print("List in Descending Order:", numbers)'''


'''num=int(input("entre the number: "))
if num%2==0:
  print("positive")
else:
  print("negative")'''

'''str1=""
if not str1:
  print("string is empty")
else:
  print("string is not empty")'''



'''num=int(input("enter a number: "))
if num%2==0:
   print("positive")
if num%2!=0:
   print("negative")
if num==0:
   print("zero")'''

'''num=int(input("enter a number: "))
if num%3==0 & num%5==0:
   print("multiple")
else:
   print("not maltiple")'''

'''num=int(input("enter a number: "))
root = int(num ** 0.5)

if root * root == num:
  print("perfect square")
else:
  print("not a square")'''


'''num=int(input("enter a number: "))
if num%2==0&num%3==0:
   print("divisible")
else:
   print("not divisible")


num = int(input("Enter a number: "))

cube_root = round(num ** (1/3))

if cube_root ** 3 == num:
    print(num, "is a perfect cube")
else:
    print(num, "is not a perfect cube")'''


'''num=int(input("entre a number: "))
if num%4==0:
   print("divisible")
else:
   print("not divisible")'''


'''year=int(input("entre the year: "))
if year%4==0:
   print("leap year")
else:
   print("not a leap year")'''

'''a=input("enter a character: ")
if a in ['a','e','i','o','u']:
   print("vowel")
else:
   print("consonent") '''

'''year = int(input("Enter year: "))

if year % 100 == 0:
    century = year // 100
else:
    century = year // 100 + 1

print("Century:", century)'''


'''num=int(input("enter a number : "))
if num>1:
   for i in range(2,num):
      if num%i==0:
         print("prime number")
      else:
         print("not a prime number")'''


num = int(input("Enter a number: "))

if num > 1:
    for i in range(2, num):
        if num % i == 0:
            print(num, "is not a prime number")
            break
    else:
        print(num, "is a prime number")
else:
    print(num, "is not a prime number")



















































   
 












